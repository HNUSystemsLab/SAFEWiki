---
title: "heap利用 1/9: First Fit"
date: 2023-02-05T15:36:08+08:00           

tags : [                                    
"heap利用",
]
categories : [                              
"heap利用",
]
keywords : [                                
"heap利用",
]
---

#  <center>First Fit <center>





该技术描述了glibc的分配器的'first-fit'行为。每当任何一个chunk（非fast chunk）被free时，最终会被放入unsorted bins.插入发生在链表的头部。在请求新的chunk（非fast chunk），先在unsorted bins中查找，因为small bins将是空的，并且从链表的尾部开始查找。如果unsorted bin中存在单个chunk，则不会进行精确检查，如果chunk的大小大于等于请求的大小，则将其拆分为两个chunk并返回。这种操作保证了先进先出。

观察以下代码:
```c
char *a = malloc(300);    // 0x***010
char *b = malloc(250);    // 0x***150

free(a);

a = malloc(250);          // 0x***010
```
chunk 'a'被分成a1，a2 两个chunk，因为请求的大小为250个字节，小于'a'的大小（300个字节）。这在`_int_malloc`中有对应的部分。
对应 unsorted bin 的状态变化如下：
1. 'a'被free
>head->a->tail
2. 'malloc'请求，返回a1，bin中留下a2
>head->a2->tail

---

在fast chunk的情况下也是如此。fast chunk被free之后会被放入到fast bins中。如前所述，fast bin维护一个单链接的列表，并从头部进行插入和删除操作，这种操作会"颠倒"获得的chunk的顺序。
观察以下代码：
```c
char *a = malloc(20);     // 0xe4b010
char *b = malloc(20);     // 0xe4b030
char *c = malloc(20);     // 0xe4b050
char *d = malloc(20);     // 0xe4b070

free(a);
free(b);
free(c);
free(d);

a = malloc(20);           // 0xe4b070
b = malloc(20);           // 0xe4b050
c = malloc(20);           // 0xe4b030
d = malloc(20);           // 0xe4b010
```
程序中使用较小的大小（20个字节），确保了在free时，chunk进入fast bin而不是unsorted bin。
对应fast bin的状态如下：
1. 'a'被free
>head->a->tail
2. 'b'被free
>head->b->a->tail
3. 'c'被free
>head->c->b->a->tail
4. 'd'被free
>head->d->c->b->a->tail
5. 'malloc'请求，返回'd'
>head->c->b->a->tail
6. 'malloc'请求，返回'c'
>head->b->a->tail
1. 'malloc'请求，返回'b'
>head->a->tail
1. 'malloc'请求，返回'a'
>head->tail

## Use after Free漏洞
在上面的示例中，我们看到malloc可能会返回先前使用以及被free的chunk，而使用被free的内存chunk很容易受到攻击。chunk一旦被free，应该假设攻击者现在可以通过各种手段控制此chunk内的数据。为了安全起见，该chunk不应该再次使用，而应总是分配一个新的chunk。
参考以下攻击示例：
```c
char *ch = malloc(20);

// Some operations
//  ..
//  ..

free(ch);

// Some operations
//  ..
//  ..

// Attacker can control 'ch'
// This is vulnerable code
// Freed variables should not be used again
if (*ch=='a') {
  // do this
}
```