---
title: "heap利用 2/9: double_free"
date: 2023-02-05T15:36:08+08:00           

tags : [                                    
"heap利用",
]
categories : [                              
"heap利用",
]
keywords : [                                
"heap利用",
]
---

多次释放资源可能会导致内存泄漏。分配器的数据结构已损坏，并可能被攻击者利用。在下面的示例程序中，一个 fastbin 块将被释放两次。现在，为了避免glibc的“双重释放或损坏（fasttop）”安全检查，将在两个资源释放操作之间释放另一个块。这意味着相同的块将由两个不同的“mallocs”返回，而这两个指针将指向相同的内存地址。如果其中一个在攻击者的控制之下，他/她可以修改另一个指针的内存，从而导致各种攻击（包括代码执行）。
如下方代码所示就存在一个double free漏洞：

```C
a = malloc(10);     // 0xa04010
b = malloc(10);     // 0xa04030
c = malloc(10);     // 0xa04050

free(a);
free(b);  // To bypass "double free or corruption (fasttop)" check
free(a);  // Double Free !!

d = malloc(10);     // 0xa04010
e = malloc(10);     // 0xa04030
f = malloc(10);     // 0xa04010   - Same as 'd' !
```

特定fastbin的状态变化情况如下：

1. `a` 被释放.
  >head -> a -> tail
1. `b` 被释放.
  >head -> b -> a -> tail
1. `a` 再一次被释放.
  >head -> a -> b -> a -> tail
1. 调用 `malloc` 分配获取 `d` 的内存空间.
  >head -> b -> a -> tail [ 'a' is returned ]
1. 调用 `malloc` 分配获取 `e` 的内存空间.
  >head -> a -> tail [ 'b' is returned ]
1. 调用 `malloc` 分配获取 `f` 的内存空间.
  >head -> tail [ 'a' is returned ]


现在，“d”和“f”指针指向相同的内存地址。其中一个中的任何更改都会影响另一个。需要注意的是，如果大小更改为smallbin范围内的大小，则此特定示例将不起作用。在第一次释放的时候，a 的下一个块会将前一个正在使用的位设置为“0”。在第二次释放期间，由于此位为“0”，将抛出“double free或corruption （!prev）”错误。

